//Calculadora.cpp
//Objetiva desenvolver as fun��es por completo da biblioteca
#include "calculadora.h"
float soma(float n1, float n2){
	return n1 + n2;	
}

float subtracao(float n1, float n2){
	return n1 - n2;	
}

float multiplicacao(float n1, float n2){
	return n1 * n2;	
}

float divisao(float n1, float n2){
	return n1 / n2;	
}


