//Calculadora.h
//Cabe�alhos de fun��es de Calculadora.cpp

float soma(float n1, float n2);

float subtracao(float n1, float n2);

float multiplicacao(float n1, float n2);

float divisao(float n1, float n2);

