#include <math.h>
float potencia(float n1, float n2);
float raiz (float n1);
bool primo (int n1);
bool imparPar (int n1);
